Provera pisanja za srpski jezik (ćirilicom i latinicom) za Hunspel

OpenOffice.org 3 dodatak sa podrškom za samoažuriranje možete preuzeti sa:
http://extensions.services.openoffice.org/project/dict-sr

Zasnovano na dict-sr izdanju 2010-08-18, Goran Rakić <grakic@devbase.net>

Za sugestije i ispravke pridružite nam se na javnoj dopisnoj listi
http://groups.google.com/group/proverapisanja


Licenciranje:
Rečnik provera pisanja za srpski jezik je objavljen pod razdvojenom trostrukom
licencom GNU Slabijom optšom javnom licencom (GNU LGPL) 2.1 ili novijom /
Mozila Javnom licencom (MPL) 1.1 ili novijom / GNU Opštom javnom licencom 2 ili
novijom, dajući Vam izbor jednog od tri skupa odredbi ovih licenci za slobodan
softver. Dodatno rečnik možete da koristite i pod uslovima Krijetiv Komons
licence Autorstvo-Deli pod istim uslovima 3.0 nepreneseno (CC BY-SA 3.0
Unported).
