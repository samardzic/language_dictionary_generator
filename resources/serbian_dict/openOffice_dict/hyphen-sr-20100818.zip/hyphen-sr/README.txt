Serbian (Cyrillic and Latin) libhyphen Hyphenation Patterns

OpenOffice.org 3 extension with autoupdate feature can be downloaded
from: http://extensions.services.openoffice.org/project/dict-sr

Based on dict-sr release 2010-08-18, Goran Rakic <grakic@devbase.net>


Source and license:
Serbian hyphenation patterns are derived from the official TeX patterns for
Serbocroatian language (Cyrillic and Latin) created by Dejan Muhamedagić
<dejan@hello-penguin.com> version 2.02 released on 22 June 2008. The format is
adopted for usage with Hyphen hyphenation library and is released under GNU
LGPL version 2.1 or later.
