Obrasci za prelom reči za srpski jezik (ćirilicom i latinicom) za libhyphen

OpenOffice.org 3 dodatak sa podrškom za samoažuriranje možete preuzeti sa:
http://extensions.services.openoffice.org/project/dict-sr

Zasnovano na dict-sr izdanju 2010-08-18, Goran Rakić <grakic@devbase.net>


Izvor i licenciranje:
Srpski obrasci za prelom reči preuzeti su iz zvaničnog skladišta obrazaca za
TeX koje je za srpskohrvatski jezik (ćirilicom i latinicom) sastavio Dejan
Muhamedagić <dejan@hello-penguin.com>, u izdanju 2.02 izdatom 22. juna 2008.
Format obrazaca je prilagođen za korišćenje uz Hyphen biblioteku za prelom reči
i objavljeni pod GNU Slabijom opštom javnom licencom (GNU LGPL) izdanje 2.1 ili
novije.
